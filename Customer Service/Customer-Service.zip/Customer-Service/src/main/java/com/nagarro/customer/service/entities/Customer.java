package com.nagarro.customer.service.entities;
import lombok.*;
import javax.persistence.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "customers")
public class Customer {
    public String getuserId;
    @Id
        @Column(name = "USERID")
        private String userId;
        @Column(name = "NAME")
        private String name;
        @Column(name = "AccNo")
        private String accNo;
        @Column(name = "EMAIL")
        private String email;
        @Column(name = "PHONE")
        private String phone;


}

