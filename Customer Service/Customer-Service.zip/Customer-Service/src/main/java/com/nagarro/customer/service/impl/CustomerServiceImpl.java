package com.nagarro.customer.service.impl;

import com.nagarro.customer.service.entities.Customer;
import com.nagarro.customer.service.exceptions.ResourceNotFoundException;
import com.nagarro.customer.service.repositories.CustomerRepository;
import com.nagarro.customer.service.services.CustomerService;
import com.sun.xml.bind.v2.schemagen.episode.SchemaBindings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerRepository customerRepository;
    private SchemaBindings modelMapper;
    private String userId;

    @Override
    public Customer saveCustomer(Customer customer) {
        //generate  unique userId
        String randomUserId = UUID.randomUUID().toString();
        customer.setUserId(randomUserId);
        return customerRepository.save(customer);

    }

    @Override
    public List<Customer> getAllCustomer() {
        return customerRepository.findAll();
    }

    @Override
    public Customer getCustomer(String userId) {
        return customerRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("Customer with" +
                "given user id is not found on server!!" + userId));
    }

    //delete
    public void deleteCustomer(String userId) {

        Customer customer = this.customerRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("Customer", "user id", userId));
        this.customerRepository.delete(customer);


    }
    //update

    public Customer updateCustomer(String userId, Customer customer) {
        Customer existingCustomer = getCustomer(userId);
        existingCustomer.setName(customer.getName());
        existingCustomer.setAccNo(customer.getAccNo());
        existingCustomer.setEmail(customer.getEmail());
        existingCustomer.setPhone(customer.getPhone());

        return customerRepository.save(existingCustomer);
    }

}


        //update
//    @Override
//    public Customer updateCustomer(String customer) {
//
//
//        Customer existingcustomer = customerRepository.findById(UserId()).orElseThrow(() -> new ResourceNotFoundException("Customer", "user id", userId));
//
//
//
//        customer.setName(customer.getName());
//        customer.setEmail(customer.getEmail());
//        customer.setAccNo(customer.getAccNo());
//        customer.setPhone(customer.getPhone());
//        Customer updatedCustomer = this.customerRepository.save(customer);
//        return customerRepository.save(existingcustomer);


///

//    private String User

